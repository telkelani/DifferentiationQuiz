from UnicodeLibrary import *
import random
from sympy import *
from sympy.printing.mathml import *
import re
from docx import Document


class Equation:
    def __init__(self,_equation): #Class constructor, each equation needs an attribute of equation
        self._equation = _equation #Whatever is declared in parenthesis becomes attribute of object

    def _RemoveLetters(self,equ):
        equ = list(equ) #Convert equation into list so I can use methods such as list.remove()
        try:
            for i in range(len(equ)): #For each element in the equation
                if equ[i] == "x" and equ[i+1] != "^": #If the element is an "x" and there isnt a circumflex after it
                    equ.insert(i, "^") #Insert a circumflex after the "x"
                    equ.insert(i+1, "1") #Insert a 1 after that element
                    #This is so that instead of converting -3x into -3 it stays as -3x
                    break #Break so it doesnt insert for the length of the loop and only once
                    
            
            
        except IndexError: #The index error will occur as the next element in the for loop is referenced
            pass
        if equ[-1] == "x":
            equ.append("^")
            equ.append("1")
        for i in equ: #Loop through parameter
            if i == "x": #Remove the element if it is an x
                equ.remove(i)
        return equ #Return the equation with only coefficients and powers

    def _expand(self,equ): #Function to expand brackets using sympy and return the equation in format I specified earlier
        x =Symbol("x") #Must initialize the x as a symbol of sympy
        EquationWithX = list(equ) #Make a list of the attribute of the equation for it to be mutable

        """Inserting * in between coefficient and x e.g 2*x"""
        IndicesOfX = [] #Store the positions of "x" in this list
       
        for i in range(len(EquationWithX)): 
            if EquationWithX[i] == "x": #If an "x" is found
                IndicesOfX.append(i) #Add the index of it to the list
        Increment = 0
        for i in range(1,len(IndicesOfX)): #All indices apart from the first one
            Increment+=1
            IndicesOfX[i]+=Increment #Add 1 to it (because when the first "*" is inserted, the list increases by one)
            #So insert() list method will insert it at an index 1 before desired.
        for i in range(len(IndicesOfX)): #Loop through the amount of "x" indices
            EquationWithX.insert(IndicesOfX[i],"*") #Insert the "*" at the appropiate index
            
            
        """Replace "^" with "**"""
        for i in range(len(EquationWithX)): 
            if EquationWithX[i] == "^": #If the symbol I was using for the superscript ^ is in the equation
                EquationWithX[i] = "**" #Replace it with the python symbol for superscript
        ExpandedEqu = expand("".join(EquationWithX)) #Use sympy function to expand, need to join first to make it into an equation
        ExpandedEqu = str(ExpandedEqu) #Make the Add data type (The data type of the return value of expand()) to string
        #Cannot convert straight to list
        ExpandedEqu = list(ExpandedEqu) #Make it a list to be mutable
     
        for i in range(len(ExpandedEqu)): 
            try: #Try and except because I will be referencing i+1, if i is maximum, i+1 will be out of bounds
                if ExpandedEqu[i] == " ":#If there is a space
                    ExpandedEqu.remove(ExpandedEqu[i])#Remove the space
                elif ExpandedEqu[i] == "*" and ExpandedEqu[i+1] == "*":  #If there are two "*" adjacent to each other
                    ExpandedEqu.pop(i+1) #Remove the second one
                    ExpandedEqu[i] = "^" #Replace the element at i with the circumflex
                elif ExpandedEqu[i] == "*":
                   #If the previous condition is not true, if element is an asterisk it must be inbetween the coefficient and "x"
                    ExpandedEqu.remove(ExpandedEqu[i]) #Remove it from the list.
                
            except IndexError: #If the list goes out of bounds do nothing, instead of crash
                pass
        """Sympy by default symplifies the equation,
        This is not ideal as this will be passed through _CoeffandPowers which separates unsimplified equations"""

        """Sorting out coefficient of 1 and constants"""
        for i in range(len(ExpandedEqu)): 
            try: #Preventing index errors (referencing i+n where n =  an integer) 
                if ExpandedEqu[i] == "x" and ExpandedEqu[i+1] != "^": #If a "^" does not proceed an x
                    ExpandedEqu.insert(i+1,"^") #Insert a circumflex
                    ExpandedEqu.insert(i+2,"1") #Insert a one after it
                elif ExpandedEqu[i] == "x" and ord(str(ExpandedEqu[i-1])) not in range(48,58): #If there isnt a number before x 
                    ExpandedEqu.insert(i,"1")#Add a one coefficient
                elif ExpandedEqu[0] == "x":
                    ExpandedEqu.insert(0,"1")
                     #Do it once, it will do it multiple times since it is in a loop
            except IndexError: 
                pass
        #Due to the simplification of sympy, a constant will always be at the end,
        #Also expanding anything will always result in a constant 
        ExpandedEqu.append("x") #Add an x
        ExpandedEqu.append("^") #Add the circumflex
        ExpandedEqu.append("0") #Add the 0         
                    
        return "".join(ExpandedEqu) #Return the equation


    def _CoeffandPowers(self,equ): #Pass the equation without letters into this method
        OriginalEquation = self.GetOriginalEquation()
        PlusorMinus = [] #This is a list needed to store the plus or minus in the equation
        if "(" in equ: #If there are brackets in the equation
            equ = equ[equ.index("(")+1:equ.index(")")] #Take the equation in the brackets and display it
            #Brackets would be added on later
            
        
        #This list will contain the index of where the + or - sign is (will not remove it as it is needed to convert str to int)
        for i in range(len(equ)): 
            if equ[i] == "+" or equ[i] == "-" or equ[i] == "D":#If the element is a +, - or has "D"
                if equ[i-1] != "^": #If the index before the + or - is not a circumflex
                    #This if statement is needed because there could be a case for example of 3x^-3
                    #The - here is not splitting the equation, it is part of the power. 
                    PlusorMinus.append(i) #Add the index to PlusorMinus
        CoeffPower = [] #This will be a 2d array to store each coefficient and power 
        Start = 0 #This will be the start of my list slicing (I need to slice the list for however many plus or minus signs there are)
        try:
            for i in range(len(PlusorMinus)):
               CoeffPower.append(equ[Start:PlusorMinus[i]])
               #This will add the values from whatever index is stored in 'Start' to the index where the + or - is indicated
               Start = PlusorMinus[i]
           #Re-assign the start variable to be the previous index where the plus or minus was
            CoeffPower.append(equ[PlusorMinus[-1]::])
        except IndexError:
            CoeffPower.append(equ)
        #If the equation only has one term append the parameter because it would only consist of
        #Coefficient and power of one term
    
        
        #Add all the elements that precede the last + or - sign         
        NewCoeffPower = [] #This is the list to store the integer form of the coefficients and the powers
        Power_List = []
        Coeff_List = []
        
        for i in range(len(CoeffPower)): #For each list in the 2D array
            for j in range(len(CoeffPower[i])): #For each element in the each list
                if "D" in CoeffPower[i]: #If "D" is in the inner list
                    
                    Coefficient ="".join(CoeffPower[i][CoeffPower[i].index("D")+1:CoeffPower[i].index("^"):])

                    Coeff_List.append(Coefficient)
                    #Append coefficient of common denominator as any element after "D" to the "^"
                else:
                    """Coefficient of 1"""
                    try:
                        if CoeffPower[i][0] == "^": 
                            CoeffPower[i].insert(0,"1")
                        #If the first element of the inner list is a circumflex
                        #Insert a "1" before the circumflex
                        #This is for the Coefficient of 1 at the start of the equation
                        CoefficientMutable = CoeffPower[i][:CoeffPower[i].index("^"):]
                        #This is the Mutable Coefficient
                        #As this a list of all the elements in each coefficient
                        
                        CoMutableString = "".join(CoefficientMutable)
                        #Make it a string for comparison as "1" coefficients do not have "1"
                        #Written before them therefore the coefficient would be just "+" or "-"

                        if CoMutableString == "+" or CoMutableString == "-":
                
                            CoefficientMutable.insert(1,"1")
                        #If that is the case then insert a "1" after this element
                            
                        Coefficient = "".join(CoefficientMutable)
                        #Now join the CoefficientMutable list
                        Coeff_List.append(Coefficient)
                        #Append it to the list of coefficients
                    except: #If there is an error trying to find "^" 
                        """Power of 0"""
                        Coefficient = "".join(CoeffPower[i])
                        #It must have a power of 0
                        #So just join the whole list together, as a power would not have been
                        #Inputted
                        Coeff_List.append(Coefficient)
                        
                #Join all the elements from the start to the circumflex (coefficient)
                try:
                    """Check if Circumflex (Power) exists"""
                    Power = "".join(CoeffPower[i][CoeffPower[i].index("^")+1::])
                    Power_List.append(Power)
                    #If the power exists join all the elements from after the "^" to the end
                except:
                    """If it does not it must mean power is 0"""
                    Power = 0
                    Power_List.append(Power)
                    #Append the power of 0 to the list of powers

                #Join all the elements after the circumflex (power)
                try:
                    NewCoeffPower.append([int(Coefficient),int(Power)])
                    #Add a list of each coefficient and power and convert them to integers
                except ValueError: #If there is a value error (one of the values are a fraction)
                    try: #Go through another try statement
                        NewCoeffPower.append([(float(int(Coefficient[0:Coefficient.index("/")]))/float(int(Coefficient[Coefficient.index("/")+1:])))
                                              ,int(Power)])
                        #Convert the coefficient fraction into a float value and convert the power into an integer
                    except ValueError: #If the power is not an integer
                        try: #Convert the integer value of the coefficient and convert the fraction power into a float
                            NewCoeffPower.append([int(Coefficient),
                                                   (float(int(Power[0:Power.index("/")]))/float(int(Power[Power.index("/")+1::])))])
                        except ValueError: #If both the coefficient and the power are fractions
                            NewCoeffPower.append([float(int(Coefficient[0:Coefficient.index("/")]))/float(int(Coefficient[Coefficient.index("/")+1:])),
                                                 (float(int(Power[0:Power.index("/")]))/float(int(Power[Power.index("/")+1::])))])
                            #Convert both coefficient and power into float values and add to 2D array.
                break#Break the loop so it doesn't add the coefficients more than once
       
        return NewCoeffPower

##        for i in range(len(NewCoeffPower)):
##            for j in range(len(NewCoeffPower[i])):
##                if "/" in NewCoeffPower[i][j]:
##                    Fraction = list(NewCoeffPower[i][j])
##                    print(Fraction)
##                    NewCoeffPower.append([int("".join(Fraction[:Fraction.index("/"):])),
##                                          int("".join(Fraction[Fraction.index("/")+1::]))])
##                    
##                    
##                else:
##                    NewCoeffPower.append([int("".join(CoeffPower[i][:CoeffPower[i].index("^"):])),
##                                              int("".join(CoeffPower[i][CoeffPower[i].index("^")+1::]))])
##                    break
        
            
       # return NewCoeffPower


    def PrepareEquation(self,equ):
        #Method to "prepare" each equation to be outputted by printEquation()
        Removed = self._RemoveLetters(equ)
        #Call _RemoveLetters() to remove the "x"s from the equation
        
        Separated = self._CoeffandPowers(Removed)
        #Call _CoeffandPowers() to separate each coefficient and power
        #Into separated list
        return Separated #Return the 2D array needed for printEquation()
    def printEquation(self,NewCoeffPower):
        FormattedEquation = [] #Empty list to concatenate all the values
        IndexOfX = []

        """For equations that are two terms long or for common denominator"""
        if len(NewCoeffPower) == 2: #If the argument has a length of 2
            try:
                NewCoeffPower[0][0] #Referencing a nested list to check if list of length 2 is a linear or a multi array
                pass  #If it is a multi array, it shouldn't return an error
                      #If it is a linear array it will as you cannot reference a nested list which doesn't exist
            except: #If it raises an error
                """For the recursion when the Common Denominator needs to be outputted in equation format"""
                for i in range(len(NewCoeffPower)):
                    if NewCoeffPower[0] == 1: #If the coefficient is 1
                        #It already has a plus or a minus sign as this was sorted out in the _CoeffandPowers() function
                        if NewCoeffPower[1] == 0: #If the power is 0 (indicating a constant)
                            FormattedEquation.append(str(NewCoeffPower[0])) #Add the coefficient only
                    elif NewCoeffPower[0] == -1: #If the coefficient is -1
                        StringCoefficient = str(NewCoeffPower[0]) #This is the string version of the coefficient
                        if NewCoeffPower[1] == 0: #If the power is  0 (indicating a constant)
                            FormattedEquation.append(StringCoefficient) #Add the coefficient only
                        FormattedEquation.append(StringCoefficient[0])
                    else: #If the coefficient is not -1 or 1
                        if abs(NewCoeffPower[0]) - int(abs(NewCoeffPower[0])) > 0:
                            CoeffFrac = Fraction(NewCoeffPower[0]).limit_denominator()
                            CoeffFrac = str(CoeffFrac)
                            print("CoeffFrac",CoeffFrac)
                            CoeffFrac = Data.printUnicode(CoeffFrac)
                            FormattedEquation.append(CoeffFrac)
                        elif int(NewCoeffPower[0]) == 0:
                            continue
                        else:
                            FormattedEquation.append(str(int(NewCoeffPower[0])))
                    FormattedEquation.append("x") #Add an x afterwards (regardless of conditions)
                    
                    if NewCoeffPower[1] == 0.5: #If the power of the term is 0.5 aka square root
                        FormattedEquation.insert(i,Data.printUnicode("^"+str(NewCoeffPower[1])))
                        #Insert the unicode √ before the last x.
                        #This is stored in variable j as the last value of j was the last index of x
                    else:
                        FormattedEquation.append(Data.printUnicode("^"+str(NewCoeffPower[1])))
                    #Add the unicode superscript value of the power
                    return "".join(FormattedEquation) #Return the bracket. #Do nothing and move to second section
        """For any other equation"""               
                 
        for i in range(len(NewCoeffPower)): #Loop through 2D array
            

            if "." in str(NewCoeffPower[i][0]): #If there is a "." in the string version of the number (a float)
                    
                FormattedEquation.append(Data.printUnicode(str(NewCoeffPower[i][0])))
                #Pass it through printUnicode() to print the coefficient into its proper fraction
                
            else:
                if NewCoeffPower[i][0] == 1: #If the coefficient is 1
                    #It already has a plus or a minus sign as this was sorted out in the _CoeffandPowers() function
                    if NewCoeffPower[i][1] == 0: #If the power is 0 (indicating a constant)
                        FormattedEquation.append(str(NewCoeffPower[i][0])) #Add the coefficient only
                     
                elif NewCoeffPower[i][0] == -1: #If the coefficient is -1
                    StringCoefficient = str(NewCoeffPower[i][0]) #This is the string version of the coefficient
                    
                    if NewCoeffPower[i][1] == 0: #If the power is  0 (indicating a constant)
                        FormattedEquation.append(StringCoefficient) #Add the coefficient only
                    else:
                        FormattedEquation.append(StringCoefficient[0])
                    #Add the coefficient with the sign to the equation
                    #Although not necessary, I declared a new variable 'StringCoefficient' to make code more understandable
                    #Instead of str(NewCoeffPower[i][0])
                    #Where a while without revisiting the code will cause confusion of its purpose
                else: #If the coefficient is not -1 or 1
                    FormattedEquation.append(str(NewCoeffPower[i][0]))
                #Add the string value of the coefficient of each list
            FormattedEquation.append("x") #Add an x afterwards (regardless of conditions)
            
            
            if NewCoeffPower[i][1] == 1: #If the second value in each nested list (the power) is 1
                pass #Don't do anything
            else: #Otherwise
                for j in range(len(FormattedEquation)): #For each element in the equation
                    #(Can't use 'i' for counter variable because 'i' is already used for main loop)
                    if FormattedEquation[j] == "x": #If the element in the list is an "x"
                        if j not in IndexOfX: #If it the index isnt already in the list of x indices
                            IndexOfX.append(j) #Add the index to the IndexOfX
                FormattedEquation.append(Data.printUnicode("^"+str(NewCoeffPower[i][1])))
                #Add the unicode superscript value of the power

        
                
            if i != len(NewCoeffPower)-1:#If i is not the last list in the 2D array
                if NewCoeffPower[i+1][0]> 0 : #If the next list's first value is positive
                    FormattedEquation.append("+") #Add a plus (If negative pass because it would already have a negative sign)
    
        Signs = [] #This list will store the indices of the + and - of the FormattedEquation
        #This will help in identifying the common denominator given that the start of it will not always be in the same position
        for i in range(len(FormattedEquation)): #Iterate through the new list
            try:
                if FormattedEquation[i] == Data.printUnicode("^0"): #If the power is to 0
                    FormattedEquation.pop(i) #Remove the index (Will remove the superscript of 0)
                    FormattedEquation.pop(i-1) #And remove the previous index (Will remove the x before it)
                elif FormattedEquation[i] == "+":
                    #If there is a plus or minus, append the index of that and add it to the 'Signs' list
                    Signs.append(i)
                elif FormattedEquation[i] == "0":
                    FormattedEquation.pop(i)
            except IndexError:
                pass
        OriginalEquation = self.GetOriginalEquation()
        if "D" in OriginalEquation:
            #If "D" is in the attribute (to indicate that the whole equation will be divided by a common denominator)
            #This cannot redirect here if EquationDividedByTerm is False
            if "(" in OriginalEquation: #If a bracket was in the original attribute
                #Slicing out the common denominator
                CommonDenominator = OriginalEquation[OriginalEquation.index("D")+1:] #Anything after "D" is common denominator
                CDCoefficient = CommonDenominator[:CommonDenominator.index("x")] #Coefficient is anything before "x"
                #There will only be one "x" so I don't need to separate by "+" or "-"
                CDPower = CommonDenominator[CommonDenominator.index("^")+1:] #Power is anything after "^"
                CDPower = Fraction(CDPower).limit_denominator() #Pass the Power into the Fraction() function to convert into fraction
                #Even if power not function, this will still return an integer (but in float form)
                CDCoeffPower = [float(CDCoefficient),float(CDPower)] #Make a new 1D list to be passed as the coefficients and powers
                #To print the equation
                #CDCoefficient is in int() and CDPower in float() because CDCoefficient will always be int() and
                #CDPower will needs to be converted to float from Fraction data type
                CommonDenominator = self.printEquation(CDCoeffPower)
                #Using recursion, the common denominator is now equal to the pretty display of the common denominator
                DivisionLine = "-"*len("".join(FormattedEquation)) #This is the physical line that will go under the equation
                #It is a series of "-" multiplied by the string length of FormattedEquation
                HalfDivLine = round(len(DivisionLine)/2) #This calculates approximately half of the division line
                return "("+"".join(FormattedEquation)+")"+Data.printUnicode("^"+OriginalEquation[OriginalEquation.index("D")-1])+"\n"+DivisionLine+"\n"+" "*(HalfDivLine-3)+"".join(CommonDenominator)
                #Return the bracket equation at the top along with expanding power,
                #The division line and place the common denominator on the bottom
                #'HalfDivLine' is taken away by 3 just for adjustment reasons (to look more or less in the middle)

            CommonDenominator = FormattedEquation[Signs[-1]+1:]
            #To identify the common denominator in 'FormattedEquation'
            #Start from the index of the last element of 'Signs', this is the last + or - sign in 'FormattedEquation'
            #Meaning it is the sign of the common denominator coefficient
            #Until the end of FormattedEquation

            
            
            del FormattedEquation[Signs[-1]:]
            #The elements of FormattedEquation that were assigned to CommonDenominator are deleted from FormattedEquation
            #This way the common denominator doesn't appear on the fraction on top
            #The reason why it is not incremented by 1 is because I want to remove the plus or minus sign as well
            DivisionLine = "-"*len("".join(FormattedEquation))
            #This is the physical line that will go under the equation
            #It is a series of "-" multiplied by the string length of FormattedEquation
            HalfDivLine = round(len(DivisionLine)/2)
            #HalfDivLine is the position which is half the division line
            
            #Reverse the CommonDenominator since it was assigned to the last element of FormattedEquation to the last plus sign
            #Therefore if it wasn't reversed, the power would go first not the coefficient e.g. ⁻¹⁷/²²x4
            
            return "".join(FormattedEquation)+"\n"+DivisionLine+"\n"+" "*HalfDivLine+"".join(CommonDenominator)
            #Return the FormattedEquation string added to a new line added to the division line, a new line
            #A half division line and then finally add the joined CommonDenominator

        elif "(" in OriginalEquation:
            #If there is a bracket in the equation but it is not divided by a term
            
            return"("+"".join(FormattedEquation)+")"+Data.printUnicode("^"+OriginalEquation[-1])
            #Return all the equation together with the unicode strings between two brackets and a superscript power at the end,
            #Which will be stored at the end of the equation.
    
        
        

            
        return "".join(FormattedEquation) #Join the equation together so that it can get rid of the delimiters.

    def GetExpandedEquation(self, equ):
        print(equ)
        OpenBracket = equ.index("(") #Locate brackets in equation using .index()
        CloseBracket = equ.index(")")
    
        Expanded = self._expand(equ[OpenBracket:CloseBracket+3])
        
        #(CloseBracket+3 because there is an expanding power
        #Which is 3 indices away from the closing bracket)
        
        return Expanded #Return the 2D array of expanded equation.

    def GetOriginalEquation(self):
        return self._equation
    def GetCoeffsandPowers(self):
        if "(" in self._equation and "D" in self._equation:
            Expanded = self._expand(self._equation[:self._equation.index("D")])
            Removed = self._RemoveLetters(Expanded)
        elif "(" in self._equation:
            Expanded = self._expand(self._equation)
            
            Removed = self._RemoveLetters(Expanded)
        else:
            Removed = self._RemoveLetters(self._equation)
        return self._CoeffandPowers(Removed)

    
            
            
        
               
                            
class Differentiation(Equation): 
    def __init__(self,_equation): #The attribute must be a parameter of the __init__() instance 
        self.EquObject = Equation(_equation) 
        #This is what composition is!
        #Creating an instance of the equation class (EquObject) which will be an object of the Differentiation class.

    def Differentiate(self, __CoeffsandPowers):
        """Change CoeffsandPowers to public"""
        OriginalEquation = self.EquObject.GetOriginalEquation()
        #Call the GetOriginalEquation() to return the equation
        #Instead of directly referencing '_equation' as the _ means protected in UML and protected can only be accessed within a class
        #This is outside of the equation class so this would be breaking convention
        #Use a public function instead to get the attribute
        if "D" in OriginalEquation: #If "D" is in the equation meaning it has a common denominator
            print("the equation has a common term so you must divide each coeffcient by the term")
            for i in range(len(__CoeffsandPowers)): #Throughout the 2D list
                __CoeffsandPowers[i][0] /=__CoeffsandPowers[-1][0]
                #Divide all the coefficients (first element) by the last one
                #Which would always be the common denominator in equations with "D"
                __CoeffsandPowers[i][1] -=__CoeffsandPowers[-1][1]
                #For the powers take away the last power from all the other powers
                #Because when terms are divided, the indices are taken away
        try: #Use a try and except statement here because an index is removed while the for loop runs
             #Anytime the length of the array that is being traversed changes length, there must be an IndexError exception
             #Since when the length of the list is declared in the for loop it is fixed to what it was before the loop started
            for i in range(len(__CoeffsandPowers)):
                __CoeffsandPowers[i][0] = __CoeffsandPowers[i][0]*__CoeffsandPowers[i][1]
                #The new coefficient is the old coefficient multiplied by its power
                __CoeffsandPowers[i][1] = __CoeffsandPowers[i][1]-1
                #The new power is one less than the old power
                if __CoeffsandPowers[i][0] == 0: #If there is a 0 anywhere in the list (a constant)
                    __CoeffsandPowers.pop(i) #Remove the whole list from there so it is not displayed
            
        except IndexError: #If there is an IndexError
            pass #Do nothing
        return __CoeffsandPowers
        #Return the 2D list of coefficients and powers so that the printEquation() function can print them out neatly
    
    #Override the printEquation() method by removing all the exceptions where the original equation has a bracket or "D"
    #Keep everything else the same as it was in the 'Equation' class printEquation() method.
    def printEquation(self, NewCoeffPower):
        FormattedEquation = [] #Empty list to concatenate all the values
        IndexOfX = []
        for i in range(len(NewCoeffPower)): #Loop through 2D array
            
            if "." in str(NewCoeffPower[i][0]): #If there is a "." in the string version of the number (a float)
                print(str(NewCoeffPower[i][0]))
                FormattedEquation.append(Data.printUnicode(str(NewCoeffPower[i][0])))
                #Pass it through printUnicode() to print the coefficient into its proper fraction
                
            else:
                if NewCoeffPower[i][0] == 1: #If the coefficient is 1
                    #It already has a plus or a minus sign as this was sorted out in the _CoeffandPowers() function
                    if NewCoeffPower[i][1] == 0: #If the power is 0 (indicating a constant)
                        FormattedEquation.append(str(NewCoeffPower[i][0])) #Add the coefficient only
                     
                elif NewCoeffPower[i][0] == -1: #If the coefficient is -1
                    StringCoefficient = str(NewCoeffPower[i][0]) #This is the string version of the coefficient
                    if NewCoeffPower[i][1] == 0: #If the power is  0 (indicating a constant)
                        FormattedEquation.append(StringCoefficient) #Add the coefficient only
                    #Add the coefficient with the sign to the equation
                    #Although not necessary, I declared a new variable 'StringCoefficient' to make code more understandable
                    #Instead of str(NewCoeffPower[i][0])
                    #Where a while without revisiting the code will cause confusion of its purpose

                else: #If the coefficient is not -1 or 1
                    FormattedEquation.append(str(NewCoeffPower[i][0]))
                #Add the string value of the coefficient of each list
            FormattedEquation.append("x") #Add an x afterwards (regardless of conditions)
            
            
            if NewCoeffPower[i][1] == 1: #If the second value in each nested list (the power) is 1
                pass #Don't do anything
            else: #Otherwise
                for j in range(len(FormattedEquation)): #For each element in the equation
                    #(Can't use 'i' for counter variable because 'i' is already used for main loop)
                    if FormattedEquation[j] == "x": #If the element in the list is an "x"
                        if j not in IndexOfX: #If it the index isnt already in the list of x indices
                            IndexOfX.append(j) #Add the index to the IndexOfX
                    
                
                FormattedEquation.append(Data.printUnicode("^"+str(NewCoeffPower[i][1])))
                #Add the unicode superscript value of the power

                
                
            if i != len(NewCoeffPower)-1:#If i is not the last list in the 2D array
                if NewCoeffPower[i+1][0]> 0 : #If the next list's first value is positive
                    FormattedEquation.append("+") #Add a plus (If negative pass because it would already have a negative sign)
        for i in range(len(FormattedEquation)): #Iterate through the new list
            try:
                if FormattedEquation[i] == Data.printUnicode("^0"): #If the power is to 0
                    FormattedEquation.pop(i) #Remove the index (Will remove the superscript of 0)
                    FormattedEquation.pop(i-1) #And remove the previous index (Will remove the x before it)
            except IndexError:
                pass

        return "".join(FormattedEquation)
    def StepByStep(self):
        OriginalEquation = self.EquObject.GetOriginalEquation()
        #Obtain original equation to see if "D" or a "(" in the equation
        CoeffsandPowers = self.EquObject.GetCoeffsandPowers()
        #Obtain coefficient and power list of the original equation 
        EachCoeffandPower = []
        #Each term will be in this list (has to be a list so the term can be passed to printEquation())
        if "(" in OriginalEquation:
            #If there is a bracket
            print("Expand Bracket")
            #Tell the user to expand the bracket
            print(self.printEquation(CoeffsandPowers))
            #Print the expanded equation (expansion occurs in GetCoeffandPowers())
        if "D" in OriginalEquation:
            #If there is a common denominator in the equation
            __CommonDenom = OriginalEquation[OriginalEquation.index("D"):]
            #The common denominator is all the elements after "D" inclusive
            #"D" is included so that CoeffsandPowers() function can tell it is a common denominator
            PreparedComDenom = self.EquObject.PrepareEquation(__CommonDenom)
            #The common denominator is prepared
            #Its own CoeffsandPowers list is made
            print("Divide each term by the common denominator",self.printEquation(PreparedComDenom))
            #Tell the user to divide each term by common denominator
            for i in range(len(CoeffsandPowers)-1):
                #For every list in the original equation's 2D list apart from the last
                #Not the last list as this contains the coefficient and power of the common denominator
                #Common denominator does not appear on numerator so this is not possible
                print(self.EquObject.printEquation(CoeffsandPowers[i]))
                #Print the current term on the numerator
                
                print("-"*len(self.EquObject.printEquation(CoeffsandPowers[i])))
                #Print a division line which covers the length of the previous output
                print(self.printEquation(PreparedComDenom))
                    

                #Print the common denominator underneath
                __DividedCoeff = CoeffsandPowers[i][0]/CoeffsandPowers[-1][0]
                #Divide the coefficient by the coefficient of the last list
                __DividedPower = CoeffsandPowers[i][1]-CoeffsandPowers[-1][1]
                #Take away the current power by the power in the last list
                #(Variable is called '__DividedPower' therefore it is a private variable)
                
                __EachCoeffandPower = [__DividedCoeff,__DividedPower]
                #List of new coefficient and new power for each term
                
                CoeffsandPowers[i][0] = __DividedCoeff
                #Update the original 2D list with the divided coefficient 
                CoeffsandPowers[i][1] = __DividedPower
                #Update the original 2D list with the new power
                print("="+self.EquObject.printEquation(__EachCoeffandPower))
                #Print each term after it

        print("Split up each term and Multiply each coefficient by each power")
        for i in range(len(CoeffsandPowers)):    #For each element in each nested list
            CoefficientVal = CoeffsandPowers[i][0]
            #The value of the coefficient is the first element of every nested list
            CoefficientStr = str(CoefficientVal)
        #String value of the coefficient in CoefficientStr
        #To be concatenated at the end remaining equation
            if abs(CoefficientVal) - int(CoefficientVal) > 0:
                #If the value of the coefficient is a float
                FractionCoeff = Fraction(CoefficientVal).limit_denominator()
                #It is converted to a fraction
                CoefficientStr = str(FractionCoeff)
                #The string value of the coefficient value is now the fraction
                CoefficientStr = Data.printUnicode(CoefficientStr)
    
                
            PowerVal = CoeffsandPowers[i][1]
            #The value of the power is the second element of each nested list
            PowerStr = str(PowerVal)
            #PowerStr will store the string value of the previous variable
            Result = CoefficientVal*PowerVal
            #The result is calculated by multiplying the value of the coefficient by the power
            
            
            if abs(PowerVal) - int(PowerVal) > 0:
                #If the value of the power is a float convert it to a fraction
                FractionPower = Fraction(PowerVal).limit_denominator()
                PowerStr = str(FractionPower)
                #Set the string value of the power to the string value of this fraction
                PowerStr = Data.printUnicode(PowerStr)
                #Display power as a fraction
            
            if abs(Result) - int(Result) > 0:
                #If the result is a float then convert it into a fraction
                ResultStr = Fraction(Result).limit_denominator()
                ResultStr = str(ResultStr)
                #Display it as a fraction as well
                ResultStr = Data.printUnicode(ResultStr)
            else:
                #The result just needs to be converted to a string if it is not a fraction
                ResultStr = str(Result)
                
                    
            
            print(CoefficientStr+"*"+PowerStr+"="+ResultStr)
            CoeffsandPowers[i][0] = Result
        if [0,0] in CoeffsandPowers:
            print("""Ignore 0 as n*0 = 0
                  and a 0 coefficient will cancel out the whole term""")
            CoeffsandPowers.remove([0,0])
        ListOfPowers = []
        #Take out each power from the equation and store here 
        SamePowerTerms= []
        #Add any terms in this list with the same power
        DuplicatePower = set() #Stores all the duplicate powers in the list
        for i in range(len(CoeffsandPowers)):
            ListOfPowers.append(CoeffsandPowers[i][1])
        #Add all the list of powers
        for i in range(len(CoeffsandPowers)):
            if ListOfPowers.count(CoeffsandPowers[i][1]) > 1:
                DuplicatePower.add(CoeffsandPowers[i][1])
                SamePowerTerms.append(CoeffsandPowers[i])
            #If there is more than 1 occurence of the power in the list of powers
            #Add the power to the set of DuplicatePowers - it will only add the first occurence
            #As sets take no duplicates
            #Add the nested list that power was in to the same power term list
        DuplicatePower = list(DuplicatePower)
        if DuplicatePower != []:
            print("Add terms with the same power together")
            
        #Make the set a list so it can support indexing
            """Bubble Sort"""
            for i in range(len(SamePowerTerms)-1):
                #For each element apart from the last one
                if SamePowerTerms[i][1] > SamePowerTerms[i+1][1]:
                    #If the current term's power is greater than the next next term's power
                    Original = SamePowerTerms[i]
                    #Then the Original is stored 
                        
                    SamePowerTerms[i] = SamePowerTerms[i+1]
                    #The current term is now the next term 
                    SamePowerTerms[i+1] = Original
                    #The previously next term is now the original term
                    #The elements have been swapped
            #At this point the 2D array will be sorted based on the size of the power

                """Summing Coefficients"""
                ListOfCoeffSums= []

                        
                CoeffSum = SamePowerTerms[0][0]
                #The sum starts with the first element of the first list,
                #As the following for loop does not
                #Iterate through the first loop
                for i in range(1,len(SamePowerTerms)):
                    #For each item in the list from the 2nd to the penultimate
                    if SamePowerTerms[i-1][1] == SamePowerTerms[i][1]:
                        #If the term's power before it is equal to the current term's power
                        
                        CoeffSum+=SamePowerTerms[i][0]
                        #Add the coefficient of that power to the Sum 
                    else: #If not
                        ListOfCoeffSums.append(CoeffSum)
                        #The summation has been complete for that term
                        #It can now be appended to the list of summations of equal powers
                        CoeffSum = SamePowerTerms[i][0]
                        #The sum is now equal to the current element
                        #this element is the start of the next same power element
                ListOfCoeffSums.append(CoeffSum)
                for i in range(len(SamePowerTerms)):
                    print(self.EquObject.printEquation(SamePowerTerms[0]),
                          "+",self.EquObject.printEquation(SamePowerTerms[i]),
                          "=",self.EquObject.printEquation([CoeffSum, SamePowerTerms[i][1]]))
                    break
                
                #As the loop does not go to the end,
                #Append the sum of the last terms at the end
                """Updating equation with summated coefficients"""
                for i in range(len(CoeffsandPowers)):
                    for j in range(len(DuplicatePower)):
                        if CoeffsandPowers[i][1] == DuplicatePower[j]:
                            #If the power of the term is equal to a duplicate power
                            CoeffsandPowers[i][0] = ListOfCoeffSums[j]
                            #All terms with that power will be updated to the Sum of that power

                for i in CoeffsandPowers:
                    #For each nested list in the 2D list
                    while CoeffsandPowers.count(i) > 1:
                    #While any of the lists occur more than once
                           CoeffsandPowers.remove(i)
                           #Remove them         
        
            
        print(self.printEquation(CoeffsandPowers))
        #Print the equation wiht the coefficients multiplied to get ready for the last stage
        print("Now take away each power by 1")
        """Represent 1 as a fraction with the denominator of the previous number
        (if the previous number is a fraction)"""
        for i in range(len(CoeffsandPowers)):
            OldPower = CoeffsandPowers[i][1] #The value of the power before the subtraction
            if abs(OldPower) - int(abs(OldPower)) > 0:
                #If the OldPower is a fraction
                OldPower = Data.printUnicode("^"+str(OldPower))
                #OldPower would now store the fraction as a superscript
                
            else: #If OldPower was not a fraction
                OldPower = str(OldPower)
                #Then just cast the integer as a string
            
            CoeffsandPowers[i][1] = CoeffsandPowers[i][1]-1
            #Updating the value of each power in the 2D list to their value take away 1
            #This is so the final equation has the updated version of the power in the 2D list
            NewPower = CoeffsandPowers[i][1]
            #This variable here is needed to show the user how the calculation has been retrieved
            if abs(NewPower) - int(abs(NewPower)) > 0:
                #If this value is a float
                FractionNewPower = Fraction(NewPower).limit_denominator()
                FractionNewPower = str(FractionNewPower)
                #Convert the float into a fraction
                
            
                Numerator = FractionNewPower[FractionNewPower.index("/")+1:]
                #Extract the numerator from this fraction
                FractionNewPower = Data.printUnicode(FractionNewPower)
                #Print the result as a fraction 
                Denominator = FractionNewPower[FractionNewPower.index("/")+1:]
                #Extract denominator from this fraction
                
                
                
                FractionMinusOne = Data.printUnicode("^"+Numerator)+"/"+Denominator
                #The minus one would be represented as a fraction
                print("--------")
                #Line to distinguish between the calculation of one term from another
                print(OldPower+"-"+FractionMinusOne+"="+FractionNewPower)
                #Output calculation
                
            else: #If the result is an integer
                NewPower = str(NewPower)
                #Convert it to a string
                print("--------")
                print(OldPower+"-1="+NewPower)
                print("--------")
                #Show the calculation
            
        print("So the answer is.....",self.EquObject.printEquation(CoeffsandPowers))
        #Output differentiated equation using printEquation() of Differentiation class
        #This should be the same as the return value of DiffSolve()
            
##class Integration(Equation): #Integration Class for the integration mode
##    def __init__(self,_equation): #Initiailize it the same as the Differentiation class
##        self.EquObject = Equation(_equation)
##        
##    def CheckIfPowerMinusOne(self, _CoeffsandPowers): #Method to check if there is a -1 power in the equation
##        Found = False #If this Boolean variable is True, another equation should be generated 
##        for i in range(len(_CoeffsandPowers)): #For each list in the 2D list
##            if _CoeffsandPowers[i][1] == -1: #If any list in the 2D list has their second element as -1
##                Found = True #It is True that the algorithm 'Found' -1
##        return Found #Return the Boolean variable indicating if a -1 is there
##    
##    def Integrate(self,_CoeffsandPowers):
##        OriginalEquation = self.EquObject.GetOriginalEquation()
##        #Call the GetOriginalEquation() to return the equation
##        #Instead of directly referencing '_equation' as the _ means protected in UML and protected can only be accessed within a class
##        #This is outside of the equation class so this would be breaking convention
##        #Use a public function instead to get the attribute
##        if "D" in OriginalEquation: #If "D" is in the equation meaning it has a common denominator
##          
##            for i in range(len(_CoeffsandPowers)): #Throughout the 2D list
##                _CoeffsandPowers[i][0] /=_CoeffsandPowers[-1][0]
##                #Divide all the coefficients (first element) by the last one
##                #Which would always be the common denominator in equations with "D"
##                _CoeffsandPowers[i][1] -=_CoeffsandPowers[-1][1]
##                #For the powers take away the last power from all the other powers
##                #Because when terms are divided, the indices are taken away
##        try: #Use a try and except statement here because an index is removed while the for loop runs
##             #Anytime the length of the array that is being traversed changes length, there must be an IndexError exception
##             #Since when the length of the list is declared in the for loop it is fixed to what it was before the loop started
##            for i in range(len(_CoeffsandPowers)):
##                IsPowerMinusOne = self.CheckIfPowerMinusOne(_CoeffsandPowers)
##                if IsPowerMinusOne:
##                    IntegrateMode()
##                    break
##                else:
##                    _CoeffsandPowers[i][1] = _CoeffsandPowers[i][1]+1 #The new power is one more than the old power
##                    _CoeffsandPowers[i][0] = _CoeffsandPowers[i][0]/_CoeffsandPowers[i][1]
##                #The new coefficient is the old coefficient divided by its new power
##            
##        except IndexError: #If there is an IndexError
##            pass #Do nothing
##        return _CoeffsandPowers
##        #Return the 2D list of coefficients and powers so that the printEquation() function can print them out neatly

##def IntegrateMode():
##    GenHard = "(4x^1+6x^0)^2D5x^2"
##    print("GenEasy",GenHard)
##    MyInt = Integration(GenHard)
##    if "(" in GenHard and "D" in GenHard:
##        """Print the original equation first"""
##        Removed = MyInt.EquObject._RemoveLetters(GenHard)
##        Separated = MyInt.EquObject._CoeffandPowers(Removed)
##        
##        """Differentiation Starts Here"""
##        OpenBracket = GenHard.index("(")
##        CloseBracket = GenHard.index(")")
##       
##        Expanded = MyInt.EquObject._expand(GenHard[OpenBracket:CloseBracket+3])
##        
##        ComDenom = GenHard[GenHard.index("D")+1:]
##        if int(ComDenom[0]) > 0:
##            Expanded+="+"+ComDenom
##        else:
##            Expanded+="-"+ComDenom
##        Removed = MyInt.EquObject._RemoveLetters(Expanded)
##        Separated = MyInt.EquObject._CoeffandPowers(Removed)
##        Int_Equation = MyInt.Integrate(Separated)
##        
##    elif "(" in GenHard:
##        """Print Original Equation First"""
##        Removed = MyInt.EquObject._RemoveLetters(GenHard)
##        Separated = MyInt.EquObject._CoeffandPowers(Removed)
##    
##        """Differentiation Starts Here"""
##        OpenBracket = GenHard.index("(")
##        CloseBracket = GenHard.index(")")
##    
##        Expanded = MyInt.EquObject._expand(GenHard[OpenBracket:CloseBracket+3])
##        Removed = MyInt.EquObject._RemoveLetters(Expanded)
##        Separated = MyInt.EquObject._CoeffandPowers(Removed)
##    
##        Int_Equation = MyDiff.Integrate(Separated)
##    else:
##        Removed = MyInt.EquObject._RemoveLetters(GenHard)
##        Separated = MyInt.EquObject._CoeffandPowers(Removed)
##        Int_Equation = MyInt.Integrate(Separated)
##        
##    def printEquation(self, NewCoeffPower):
##        FormattedEquation = [] #Empty list to concatenate all the values
##        IndexOfX = []
##        for i in range(len(NewCoeffPower)): #Loop through 2D array
##            
##            if "." in str(NewCoeffPower[i][0]): #If there is a "." in the string version of the number (a float)
##                    
##                FormattedEquation.append(Data.printUnicode(str(NewCoeffPower[i][0])))
##                #Pass it through printUnicode() to print the coefficient into its proper fraction
##                
##            else:
##                if NewCoeffPower[i][0] == 1.0: #If the coefficient is 1
##                    #It already has a plus or a minus sign as this was sorted out in the _CoeffandPowers() function
##                    if NewCoeffPower[i][1] == 0: #If the power is 0 (indicating a constant)
##                        FormattedEquation.append(str(NewCoeffPower[i][0])) #Add the coefficient only
##                    else:
##                        continue
##                     
##                elif NewCoeffPower[i][0] == -1: #If the coefficient is -1
##                    StringCoefficient = str(NewCoeffPower[i][0]) #This is the string version of the coefficient
##                    if NewCoeffPower[i][1] == 0: #If the power is  0 (indicating a constant)
##                        FormattedEquation.append(StringCoefficient) #Add the coefficient only
##                    
##                    #Add the coefficient with the sign to the equation
##                    #Although not necessary, I declared a new variable 'StringCoefficient' to make code more understandable
##                    #Instead of str(NewCoeffPower[i][0])
##                    #Where a while without revisiting the code will cause confusion of its purpose
##                else: #If the coefficient is not -1 or 1
##                    FormattedEquation.append(str(NewCoeffPower[i][0]))
##                #Add the string value of the coefficient of each list
##            FormattedEquation.append("x") #Add an x afterwards (regardless of conditions)
##            
##            
##            if NewCoeffPower[i][1] == 1: #If the second value in each nested list (the power) is 1
##                pass #Don't do anything
##            else: #Otherwise
##                for j in range(len(FormattedEquation)): #For each element in the equation
##                    #(Can't use 'i' for counter variable because 'i' is already used for main loop)
##                    if FormattedEquation[j] == "x": #If the element in the list is an "x"
##                        if j not in IndexOfX: #If it the index isnt already in the list of x indices
##                            IndexOfX.append(j) #Add the index to the IndexOfX
##                if NewCoeffPower[i][1] == 0.5: #If the power of the term is 0.5 aka square root
##                    FormattedEquation.insert(j,Data.printUnicode("^"+str(NewCoeffPower[i][1])))
##                    #Insert the unicode √ before the last x.
##                    #This is stored in variable j as the last value of j was the last index of x
##                elif NewCoeffPower[i][1] == -0.5: #If the power is -0.5 aka negative square root
##                    FormattedEquation.insert(j,Data.printUnicode("^"+str(0.5))) #Insert √ in the same place as the positive one
##                 
##                    FormattedEquation[j-1] = "-"+Data.printUnicode(str(NewCoeffPower[i][0]))
##                    #The element before it (the coefficient) is made to be negative by multiplying the coefficient by -1
##                else:
##                    FormattedEquation.append(Data.printUnicode("^"+str(NewCoeffPower[i][1])))
##                #Add the unicode superscript value of the power
##
##                
##                
##            if i != len(NewCoeffPower)-1:      #If i is not the last list in the 2D array
##                if NewCoeffPower[i+1][0]> 0 :    #If the next list's first value is positive
##                    FormattedEquation.append("+")   #Add a plus (If negative pass because it would already have a negative sign)
##        for i in range(len(FormattedEquation)):   #Iterate through the new list
##            try:
##                if FormattedEquation[i] == Data.printUnicode("^0"): #If the power is to 0
##                    FormattedEquation.pop(i) #Remove the index (Will remove the superscript of 0)
##                    FormattedEquation.pop(i-1) #And remove the previous index (Will remove the x before it)
##            except IndexError:
##                pass
##
##        return "".join(FormattedEquation)+"+c" #c is the constant to be found         
def GenerateEasyEquation():
    Equation = "" #String to store the final concatenated equation
    Coeff_List = [] #The list of coefficients (will contain two random coefficients)
    Power_List = [] #Same as above but for exponents
    End_Constant = random.randint(1,9) #The constant at the end will be positive
    End_Constant = str(End_Constant) #Convert to string so "x^0" can be appended to it
    for i in range(2): #Loop twice
        Coefficient = random.randint(-4,4) #Will pick a number between -4 and 4
        while Coefficient == 0: #If the coefficient is 0 (while loop because the generator could generate a 0 again)
            Coefficient = random.randint(-4,4) #Generate a new random number
            
            
        Power = random.randint(1,4) #Same for power
        while Power == 0: 
            Power = random.randint(1,4)
        Coeff_List.append(Coefficient) #Add the coefficient to the list of coefficients
        Power_List.append(Power) #Add the power to the list of powers
        if len(Power_List) ==2: #If the power list has a length of 2 
            while Power_List[0] == Power_List[1]: #If the first power is the same as the second power
                Power_List.pop(1) #Remove the last index
                Power = random.randint(1,4) #Pick another number between 1 and 9 
                Power_List.append(Power) #Add the power to the list of powers

    End_Constant+="x^0"
    if Coeff_List[1] > 0:
        Equation = str(Coeff_List[0])+"x^"+str(Power_List[0])+"+"+str(Coeff_List[1])+"x^"+str(Power_List[1])+"+"+End_Constant
        #If second coefficient is positive insert a plus before it 
    else:
        Equation = str(Coeff_List[0])+"x^"+str(Power_List[0])+str(Coeff_List[1])+"x^"+str(Power_List[1])+"+"+End_Constant
        #If not join it to the end of the last power (the negative coefficient already has a minus sign so not required to add minus)
    #Put all the parts of the equation together by concatenation
    return Equation #Return the concatenated string


    
def GenerateMediumEquation():
    """Initialize Containers"""
    Coeff_List = [] #List of coefficients
    Power_List = [] #List of powers
    Equation = "" #Equation to be returned at the end
    AmountOfParts = random.randint(3,5) #Randomizes how many parts the equation will have e.g. 3 parts would be Cx^p+C1x^p1+C2x^p2
                                        #Where C = Coefficient and p = Power

    """For loop to generate coefficients and powers"""
    for i in range(AmountOfParts): #For i in that amount of times
        """Coefficients"""
        Coefficient = random.randint(-20,20) #Randomly generated a coefficient in the boundaries of -20 to 20 
        while Coefficient == 0: #While the Coefficient randomizes to 0 
           Coefficient = random.randint(-20,20) #Randomize another number until it is not 0 anymore
        Coeff_List.append(Coefficient) #Add the Coefficient to the list of coefficients

        """Powers"""
        IsFractionPower = random.choice([True,False]) #Randomly choose if the individual power will be a fraction
        
        
        #Will create a mix of integer and fraction powers
        if IsFractionPower: #If it is a fraction
            Numerator = random.randint(-9,9) #Generate a random numerator between -9 and 9
            while Numerator == 0: #If the numerator is 0 generate another numerator until it is not 0 anymore
                Numerator = random.randint(-9,9)
            Denominator = random.randint(1,9) #Generate a random denominator between 1 and 9, (Denominators are never negative)
            Power_Float = Numerator/Denominator #Create a float from this by dividing numerator by denominator
            #(to be converted to fraction later)
            while abs(Power_Float) - int(Power_Float) == 0: #If the Fraction simplifies to a whole number (it would be single digit)
                Denominator = random.randint(1,9) #Create a new denominator
                Power_Float = Numerator/Denominator #Divide numerator by denominator again to get the same result.
                
            Power_List.append(Power_Float) #Add the float to the list of powers
        else: #If the power is not a fraction
            Power = random.randint(-20,20) #Generate a random power between -20 and 20 
            while -9 <=Power <= 9: #If the power is a single digit number
                Power = random.randint(-20,20) #Randomly select another number until the value is double digit
            Power_List.append(Power) #Add that power to the list of powers

    """Check if Powers are the same"""
    for i in Power_List: #For each power in Power_List
        while Power_List.count(i) > 1: #If that power occurs more than once (duplicate)
            i = random.randint(-20,20) #Assign it to another randomly generated power
            while  -9 <= i <= 9: #If it is a single digit number
                i = random.randint(-20,20) #Generate another number for the power until it is not a single digit number
                
    """Add positive sign to coefficients"""
    for i in range(1, len(Coeff_List)): #From the second to the last coefficient
        if Coeff_List[i] > 0: #If the coefficient is positive
            Coeff_List[i] = str(Coeff_List[i]) #Convert to a string to concatenate "+"
            Coeff_List[i] = "+"+Coeff_List[i] #Add plus before the coefficient

    """Constants"""
    ConstantIncluded = random.choice([True,False]) #Randomly decide if Constant should be included
    
    if ConstantIncluded: #If it chooses to include constant
        Constant = random.randint(-20,20) #Generate a random constant between -20 and 20
        while Constant == 0: #If the Constant is 0
            Constant = random.randint(-20,20) #Generate a different constant until it is not 0

            
    """Putting equation together"""
    print(AmountOfParts)
    print(len(Power_List))
    for i in range(AmountOfParts): #For each part of the equation
        if abs(Power_List[i]) -int(Power_List[i]) > 0: #If the positive value of the float- rounded down intger is over 0
        
            PowerFloatAsFrac = Fraction(Power_List[i]).limit_denominator() #Convert the float into fraction using Fraction()
            PowerFloatAsFrac = str(PowerFloatAsFrac) #Make it a string insted of fractions attribute
            
            Equation +=str(Coeff_List[i])+"x"+"^"+PowerFloatAsFrac
            #Concatenate the Coefficient at that point, "x" then "^" then fraction  
        else:
            Equation += str(Coeff_List[i])+"x"+"^"+str(Power_List[i])
            #If there is no fraction just concatenate the power onto the circumflex when Power_List element is converted to string  
        
    """Adding constant at the end (if it is included)"""
    if ConstantIncluded: #If the computer adds an element
        if Constant > 0: #If it is a positive number
            Constant="+"+str(Constant)+"x^0" #Add a plus sign before constant, convert constant to string and add "x^0" after it
            #For constant to be handled by printEquation
            Equation+=Constant #Add Constant at the end of Equation
        else:
            Equation+=str(Constant)+"x^0" #Add constant at the end of Equation without plus if the constant is negative
    return Equation #Return the equation to be passed on as Equation class attribute.
            
##def InnerBracketEquationGenerator():
##    IsPowerFraction = random.choice([True,False])
##    InnerBracket = []
##    Coefficient = 0
##    while Coefficient == 0:
##        Coefficient = random.randint(-20,20)
##    Coefficient = str(Coefficient)
##    Power = 0
##    while Power == 0:
##        if IsPowerFraction:
##            
##        else:
##            Power = str(random.randint(-20,20))
##    return 

"""Hard equation do not work well with differentiation mode
 as some top heavy fractions with three digit numerators
 which UnicodeLibrary does not accept"""

def GenerateInnerBracket():
    Coefficient = 0
    IsPowerFraction = random.choice([True,False])
    while Coefficient == 0:
        Coefficient = random.randint(-9,9)
    Coefficient = str(Coefficient)

    if IsPowerFraction:
        Numerator = random.randint(1,9)
        Denominator = random.randint(1,9)
        PowerFrac = Fraction(Numerator/Denominator).limit_denominator()
        Power = str(PowerFrac)
    else:
        Power = random.randint(1,9)
        Power = str(Power)
    Constant = random.randint(-9,9)
    if Constant > 0:
        Constant = str(Constant)
        Constant = "+"+Constant
    else:
        Constant = str(Constant)
    InnerBracket = Coefficient+"x^"+Power+Constant+"x^0"
    return InnerBracket
    
        
def GenerateHardEquation():
    "Initializing Variables"
    Numerator = [] #Numerator is the equation on top, when it is divided by a common denominator
    CommonDenominator = [] #Denominator is the term at the bottom, when it is needed
    Coeff_List = [] #Here are the list of coefficients, so I can check each one to find out if they are positive or negative
    NumberOfParts = 3 #Number of parts of the equation will always be 3, as this is reasonable
    FormattedEquation = [] #This is the return value which will be joined to a string to make an equation
    EquationDividedByTerm = random.choice([True,False])
    #This is a random selection whether the whole equation is to be in fraction form
    IsNumeratorInBrackets = random.choice([True,False])
    #Random selection whether the top part will be a fraction
    Power_List = []

    "IsNumeratorInBrackets True?"
    if IsNumeratorInBrackets: #If the equation is in brackets
        BracketPower = random.randint(2,3) #2 or 3 is generated
        #Exponent 2 and exponent 3 are the highest before it gets too complicated 
        Bracket_Numerator = "".join(["(",GenerateInnerBracket(),")^",str(BracketPower)])
        #Join the elements of a bracket first, the return value of the easy equation, another bracket, ending with "^[power]"

    "Assigning coefficients and power to each term"
    IsCommonDenominatorPowerFloat = random.choice([True,False])
    #This is a random choice for whether the denominator should be a float
    IsDenominatorPowerFloat =  random.choice([True,False])
    
    for i in range(NumberOfParts):
        #For every part of the non-bracket equation
        IsPowerFloat = random.choice([True,False]) #Choose whether the power will be a fraction
        
        Coefficient = 0 #Initialize Coefficient
        while Coefficient == 0: #If the coefficient is 0 (which it will be at the start)
            Coefficient = random.randint(-20,20) #Generate a random number between -20 and 20
            
        Coeff_List.append(Coefficient) #Add the coefficient to the coeffcient list
        try: #If the coefficient list is in bounds
            for j in range(len(Coeff_List)): #For each element in the coefficient list
                if Coeff_List[j+1] > 0: #If the element after it is positive
                    Coeff_List.pop(j) #Remove the current element
                
                    Numerator.append("+") #And add a plus        
        except IndexError: #If it goes out of bounds
            pass #Do nothing
        Numerator.append(str(Coefficient)) #Add the coefficient to the equation
        Numerator.append("x") #Add x to accompany it

        for i in Power_List: #For each power in Power_List
            while Power_List.count(i) > 1: #If that power occurs more than once (duplicate)
                i = random.randint(-50,50) #Assign it to another randomly generated power

        if IsPowerFloat: #If the power is a float
            Power_Num = random.randint(-50,50) #Initialize numerator of power 
            Power_Den = random.randint(2,50) #Randomize the denominator of the power between 2 and 50
            #Do not want it to be 1 or 0, because divide by 1 is numerator, divide by 0 is impossible
            Power = Power_Num/Power_Den
            while Power_Num ==0: #While the numerator is 0
                Power_Num = random.randint(-9,9) #Generate a numerator between -50 and 50
                Power = Power_Num/Power_Den #Divide the numerator by the denominator to get a float value
            
                    
        
            while abs(Power) - int(Power) == 0: #While the float is minus its truncated-down-to-integer value is equal to 0.
                Power_Den = random.randint(2,50)#Generate a different denominator
                Power = Power_Num/Power_Den #Divide that by the original numerator
            PowerIntoFraction = str(Fraction(Power).limit_denominator()) #Convert the float into a fraction
       
        
            Numerator.append("^"+PowerIntoFraction) #Add to the equation,"^"+whatever the fraction was
        else: #If the power is not  a float
            Power = 0 #The power is equal to 0 
            while Power == 0 or -9<= Power <=9: #While the power is 0 or it is a 1 digit number
                
                Power = random.randint(-50,50)#Generate a power between -50 and 50
            
            Numerator.append("^"+str(Power)) #Add this power to the equation like for the previous if statement
        
        Power_List.append(Power) #Append the power to the list of powers created in this loop


    "Forming Final Equation"        
    if EquationDividedByTerm: #If the program decides to divide the equation by the term 
        if IsNumeratorInBrackets and IsCommonDenominatorPowerFloat:
            #If the program decides that the equation numerator will be in brackets
            #AND the power of the denominator is a float
            CommonDenominatorPowerNum = random.randint(-10,10) #Randomize the power numerator from -10 to 10 
            CommonDenominatorPowerDen = random.randint(2,10) #Randomize the power denominator from 2 to 10

            while CommonDenominatorPowerNum == 0: #While the common denominator float is 0
                CommonDenominatorPowerNum = random.randint(-10,10) #Generate a new numerator for the common denominator power

            CDPower = CommonDenominatorPowerNum/CommonDenominatorPowerDen
            while abs(CDPower) - int(CDPower) == 0: #While the float is minus its truncated-down-to-integer value is equal to 0.
                CommonDenominatorPowerNum = random.randint(1,10)#Generate a different numerator
                CDPower = CommonDenominatorPowerNum/CommonDenominatorPowerDen #Divide that by the original denominator
            CDPowerIntoFraction = str(Fraction(CDPower).limit_denominator()) #Convert the float into a fraction
            
            CommonDenominatorCoeff = random.randint(1,9) #Randomize the coefficient from 1 to 20
            #Common Denominator cannot have negative coefficient as fractions do not have negative denominators. 
            CommonDenominator.append(str(CommonDenominatorCoeff)) #Append this to the common denominator
            CommonDenominator.append("x") #Add an "x" to the common denominator
            CommonDenominator.append("^"+CDPowerIntoFraction)
            #Join the numerator and denominator of power and put it into one
            JoinedCommonDenominator = "".join(CommonDenominator)
            #Join the whole common denominator together
            FormattedEquation = Bracket_Numerator+"D"+JoinedCommonDenominator
            #The final equation returns the equation in brackets plus two "/" and the common denominator
            #I am going to use "//" as an indicator that the whole equation is to be divided by the proceeding term
        elif IsCommonDenominatorPowerFloat:
            #If the power of the common denominator is a float but the equation is not in brackets
            CommonDenominatorPowerNum = random.randint(-9,9) #Randomize a numerator and a denominator for it
            CommonDenominatorPowerDen = random.randint(2,9)
            while CommonDenominatorPowerNum == 0: #While the common denominator float is 0
                CommonDenominatorPowerNum = random.randint(-9,9) #Generate a new numerator for the common denominator power
            CDPower = CommonDenominatorPowerNum/CommonDenominatorPowerDen
            while abs(CDPower) - int(CDPower) == 0: #While the float is minus its truncated-down-to-integer value is equal to 0.
                CommonDenominatorPowerNum = random.randint(1,9)#Generate a different numerator
                CDPower = CommonDenominatorPowerNum/CommonDenominatorPowerDen #Divide that by the original denominator
            CDPowerIntoFraction = str(Fraction(CDPower).limit_denominator()) #Convert the float into a fraction
            
            CommonDenominatorCoeff = random.randint(1,9) #Randomize a coefficient
            CommonDenominator.append(str(CommonDenominatorCoeff))
            CommonDenominator.append("x")
            CommonDenominator.append("^"+CDPowerIntoFraction)
            JoinedNumerator = "".join(Numerator) #Instead of 'Bracket_Numerator'
            #Now it is the numerator list created before joined into one
            JoinedCommonDenominator = "".join(CommonDenominator) #Join the common denominator
            FormattedEquation = JoinedNumerator+"D"+JoinedCommonDenominator
            #Will return the equation without brackets all divided by the common denominator

        elif IsNumeratorInBrackets: #If the numerator is in brackets but common denominator power is integer
            CommonDenominatorCoeff = random.randint(1,9) #Randomize an integer coefficient and power
            CommonDenominatorPower = random.randint(-9,9)
            while CommonDenominatorPower == 0: #While the common denominator power is 0
                CommonDenominatorPower = random.randint(-9,9) #Generate a new common denominator power

            CommonDenominator = [str(CommonDenominatorCoeff),"x^",str(CommonDenominatorPower)]
            #Populate list with common denominator coefficient, x^ and common denominator power
            JoinedCommonDenominator = "".join(CommonDenominator) #Join the common denominator list together
            FormattedEquation = Bracket_Numerator+"D"+JoinedCommonDenominator
            #The equation in brackets is divided by the common denominator with an integer power
            
        else: #If the equation is not in brackets and the common denominator's power is not a float
            CommonDenominatorCoeff = random.randint(1,9) #Generate integer coefficient and power for common denominator
            CommonDenominatorPower = random.randint(-9,9)
            while CommonDenominatorPower == 0: #While the common denominator power is 0
                CommonDenominatorPower = random.randint(-9,9) #Generate a new common denominator power
            CommonDenominator = [str(CommonDenominatorCoeff),"x^",str(CommonDenominatorPower)]
            #Populate list with common denominator coefficient, x^ and common denominator power
            JoinedNumerator = "".join(Numerator) #Join the numerator equation
            JoinedCommonDenominator = "".join(CommonDenominator)
            FormattedEquation = JoinedNumerator+"D"+JoinedCommonDenominator
            #Return the numerator equation divided by the common denominator with an integer power
    elif IsNumeratorInBrackets: #If the equation is in brackets but not divided by any term
        FormattedEquation = Bracket_Numerator #The equation returned is equal to the equation in brackets

    else: #If the equation is not in brackets and the equation is not divided by any term
        JoinedNumerator = "".join(Numerator) #Join the numerator
        FormattedEquation = JoinedNumerator #The equation is equal to the numerator
    return FormattedEquation #Return anything that is in 'FormattedEquation'
   
def Menu():
    print("Hello, Welcome to differentiation and integration solver for C1")
    print("Select a Mode:")
    print("Differentiation Mode (D)")
    print("Print Tests (T)")
    print("Quit (Q)")
    ProgramChoice = input(">>>")
    if ProgramChoice.upper() == "D":
        print("Differentiation Mode")
        DiffMode()
    elif ProgramChoice.upper() == "T":
        print("Teacher's Corner")
        PrintTest()
        
        
    

def DiffMode():
    Streak = 0
    #Streak is to store how many questions the user has consecutively gotten right
    ScoreWhenStreakEnds = []
    End = False
    #End is when the user decides to quit the game
    Difficulty = "Easy" #Program starts at Easy level
    while End == False: #While End is False
        print(Difficulty) #Print the difficulty level
        if Difficulty == "Easy": #If the difficulty is easy
            GeneratedEqu = GenerateEasyEquation()
            
            #The equation to generate is from easy equation
        elif Difficulty == "Medium": #If the difficulty is medium
            GeneratedEqu = GenerateEasyEquation()
            #Then the equation to generate is from this function 
        elif Difficulty == "Hard": #If the difficulty is hard 
            GeneratedEqu = GenerateEasyEquation()
            #The equation is comes from this function
        MyDiff = Differentiation(GeneratedEqu)
        #Create an instance of class Differentiation
        """Print the original equation first"""
        #Before any equation is printed, it must pass through these two functions
        Prepared = MyDiff.EquObject.PrepareEquation(GeneratedEqu)
        
        #Print the original equation (All these methods come from Equation class)
        ValidAnswer = False #The answer is not valid yet
        while not ValidAnswer: #While it is not valid
            print("Differentiate:")
            print(MyDiff.EquObject.printEquation(Prepared))
            InvalidCharFound = False #An invalid character has not been found yet
            print("""How to input equation:
                  Fraction = numerator/denominator 
                  (Negative denominator is not accepted)

                  Each term should be written like this: [Coefficient]x^[Power]

                  Example equations: Input:3x^2+4x+43x^4-43
                                     Output:3x²+4x+43x⁴-43

                                     Input:3/4x^5/3
                                     Output:³/₄x⁵/³
                  Constants are accepted E.g. 3, 34/3""")                 
                  
                  
                                
            Answer = input("Enter your input or press Q to quit\nPress Enter when you're done")
            #Answer input
            PlusOrMinus = [] #List of plus or minus indices
            Start = 0 #Start of list slice is 0
            Terms = [] #Add terms into this list so they can be checked by re
            for i in range(len(Answer)):
                #For each index in the input
                if Answer[i] == "+" or Answer[i] == "-" and Answer[i-1] != "^":
                    #If the input is a plus or the input is a minus
                    PlusOrMinus.append(i)
                    #Append the index to the PlusOrMinus list
                    
            for i in range(len(PlusOrMinus)):
                #For each in element in PlusOrMinus
                Terms.append(Answer[Start:PlusOrMinus[i]])
                #Add to the Terms the elements from the index of Start
                #To the position of the index of PlusOrMinus
                Start = PlusOrMinus[i]
                #Start is now the index of the previous plus or minus sign
            
            Terms.append(Answer[Start:])
            #When the for loop is iterated through, it will miss out the last term
            #As the last list slice will be to the index of the last "+" or "-" in Answer
            #Start will be the index of the last plus or minus sign
            #Therefore just append everything from the last plus or minus sign
            ValidInputs = [] #This stores all the matches for the valid input
            ValidPattern = re.compile("[\+\-]?[\d]*[x]?([\^][\-]?[\d]+)?|([\+\-]?[\d]+[/][\d]+|[\+\-]?[\d])?[x]?([\^][\-]?[\d]+|[\^][\-]?[\d]+[/][\d]+)?")
            #This variable stores the return value of re.compile()
            #This function's purpose is to 'compile' a custom pattern (accepted strings)

            
            for i in Terms: #For each element in the terms
                if i == "+" or i == "-": #If the term is JUST a "+" or a "-" 
                    InvalidCharFound = True #Then it is an invalid character
                else: #Otherwise
                    ValidInputs.append(re.fullmatch(ValidPattern,i))
                #If the WHOLE term matches the compiled pattern it is valid
                #If not it will return None (Null value)
            

            if Answer == "": #For when user just presses the enter key 
                InvalidCharFound = True
                #It is an invalid character     
            
            if Answer.upper() == "Q":
                print("Your longest streak was", max(ScoreWhenStreakEnds))
                print("Average streak was", sum(ScoreWhenStreakEnds)/len(ScoreWhenStreakEnds))
                Menu()
                return
                #Return here is crucial so that it does not continue to output data  
                #When user presses quit in main menu.
                #Loop through contents of answer

            for i in ValidInputs: #For each element in the ValidInputs list
                if i == None: #If the element is a null value
                    InvalidCharFound = True #Invalid character was found
                    
            
                
                

                    
            if not InvalidCharFound: 
                #If there was not an invalid character found 
                ValidAnswer = True #Then the answer is True.
                

             
            
            
                
        MyAns = Differentiation(Answer)
        #The answer equation is now an instance of Differentiation class
        #Prepare equation to be outputted
        Prepared = MyAns.EquObject.PrepareEquation(Answer)
        InputEquation = MyAns.EquObject.printEquation(Prepared)
        #InputEquation is the display of the user input
        print("Your input was",InputEquation)
        CorrectAnswer = DiffSolve(GeneratedEqu)
        #Use DiffSolve() to solve the question (generated equation)
        print("Correct Answer", CorrectAnswer)
        if InputEquation == CorrectAnswer: 
            print("Correct!") #If the input is the same as the correct answer
            Streak+=1 #Add one to the streak
        else:
            ScoreWhenStreakEnds.append(Streak)
            print(ScoreWhenStreakEnds)
            Streak = 0 #If not the streak is 0
            
            MyDiff.StepByStep()
        if Streak == 0: #If the streak is 0 and any number that is not two
            Difficulty = "Easy" #It is easy
        elif Streak == 2: #If the streak is 2 
            Difficulty = "Medium" #It becomes medium
        elif Streak == 4: #Until the streak is 4
            Difficulty = "Hard"
            #Then it will stay on hard difficulty until the user makes mistake 
            
            
def DiffSolve(GeneratedEqu):
    #DiffSolve is a function to solve the generated equation as a guideline
    #To see if the user's answer is the same as the correct answer
    MyDiff = Differentiation(GeneratedEqu) #Make a Differentiation object
    if "(" in GeneratedEqu and "D" in GeneratedEqu:
        #If there is a bracket and it is divided by a common denominator
        """Differentiation Starts Here"""
        Expanded = MyDiff.EquObject.GetExpandedEquation(GeneratedEqu)
        #Expand the bracket
        
        ComDenom = GeneratedEqu[GeneratedEqu.index("D")+1:]
        #Separate common denominator from the rest of the equation
        
        Expanded+="+"+ComDenom
        #Add a plus to the common denominator
        #Append it to the expanded equation
        #Display the whole equation with common denominator
        #This will call the public method PrepareEquation()
        #Which runs protected methods _RemoveLetters() and _CoeffandPowers()
        #This prevents public access of protected variables
        Prepared = MyDiff.EquObject.PrepareEquation(Expanded)
        #Differentiate equation
        Diff_Equation = MyDiff.Differentiate(Prepared)
        
    elif "(" in GeneratedEqu:
        """Differentiation Starts Here"""
        Expanded = MyDiff.EquObject.GetExpandedEquation(GeneratedEqu)
        #Expand brackets 
        Prepared = MyDiff.EquObject.PrepareEquation(Expanded)
        #Create 2D array of each coefficient and power
        Diff_Equation = MyDiff.Differentiate(Prepared)
    else:
        #If there are no brackets and it is not divided by anything
        #Prepare the equation
        Prepared = MyDiff.EquObject.PrepareEquation(GeneratedEqu)
        #Differentiate it
        Diff_Equation = MyDiff.Differentiate(Prepared)

    """If the differentiated equation turns out to have the same power, it must be simplified"""    
    ListOfPowers = []
    #Take out each power from the equation and store here 
    SamePowerTerms= []
    #Add any terms in this list with the same power
    DuplicatePower = set() #Stores all the duplicate powers in the list
    for i in range(len(Diff_Equation)):
        ListOfPowers.append(Diff_Equation[i][1])
    #Add all the list of powers
    for i in range(len(Diff_Equation)):
        if ListOfPowers.count(Diff_Equation[i][1]) > 1:
            DuplicatePower.add(Diff_Equation[i][1])
            SamePowerTerms.append(Diff_Equation[i])
        #If there is more than 1 occurence of the power in the list of powers
        #Add the power to the set of DuplicatePowers - it will only add the first occurence
        #As sets take no duplicates
        #Add the nested list that power was in to the same power term list
    DuplicatePower = list(DuplicatePower)
    #Make the set a list so it can support indexing
    """Bubble Sort"""
    for i in range(len(SamePowerTerms)-1):
        #For each element apart from the last one
        if SamePowerTerms[i][1] > SamePowerTerms[i+1][1]:
            #If the current term's power is greater than the next next term's power
            Original = SamePowerTerms[i]
            #Then the Original is stored 
                
            SamePowerTerms[i] = SamePowerTerms[i+1]
            #The current term is now the next term 
            SamePowerTerms[i+1] = Original
            #The previously next term is now the original term
            #The elements have been swapped
    #At this point the 2D array will be sorted based on the size of the power

        """Summing Coefficients"""
        ListOfCoeffSums= []
        print(SamePowerTerms)
                
        CoeffSum = SamePowerTerms[0][0]
        #The sum starts with the first element of the first list, as the following for loop does not
        #Iterate through the first loop
        for i in range(1,len(SamePowerTerms)):
            #For each item in the list from the 2nd to the penultimate
            if SamePowerTerms[i-1][1] == SamePowerTerms[i][1]:
                #If the term's power before it is equal to the current term's power
                
                CoeffSum+=SamePowerTerms[i][0]
                #Add the coefficient of that power to the Sum 
            else: #If not
                ListOfCoeffSums.append(CoeffSum)
                #The summation has been complete for that term and it can now be appended to the list
                #Of summations of equal powers
                CoeffSum = SamePowerTerms[i][0]
                #The sum is now equal to the current element as this element is the start of the next
                #Same power element
        ListOfCoeffSums.append(CoeffSum)
        #As the loop does not go to the end, append the sum of the last terms at the end
        """Updating equation with summated coefficients"""
        for i in range(len(Diff_Equation)):
            for j in range(len(DuplicatePower)):
                if Diff_Equation[i][1] == DuplicatePower[j]:
                    #If the power of the term is equal to a duplicate power
                    Diff_Equation[i][0] = ListOfCoeffSums[j]
                    #All terms with that power will be updated to the Sum of that power
        print("Duplicate Power", DuplicatePower)
        print("ListOfCoeffSums", ListOfCoeffSums)


        for i in Diff_Equation:
            #For each nested list in the 2D list
            while Diff_Equation.count(i) > 1:
            #While any of the lists occur more than once
                   Diff_Equation.remove(i)
                   #Remove them         
                                  
          
    return MyDiff.printEquation(Diff_Equation)
    #Return the printed output of each equation
    #Use the printEquation() of the 'Differentiation' class
    #So brackets are not printed out

def PrintTest():
    Equ = Equation(GenerateEasyEquation())
    OriginalEquation = Equ.GetOriginalEquation()
    x = Symbol("x") #Must initialize the x as a symbol of sympy
    EquationWithX = list(OriginalEquation)
    #Make a list of the attribute of the equation for it to be mutable

    """Inserting * in between coefficient and x e.g 2*x"""
    IndicesOfX = [] #Store the positions of "x" in this list
   
    for i in range(len(EquationWithX)): 
        if EquationWithX[i] == "x": #If an "x" is found
            IndicesOfX.append(i) #Add the index of it to the list
    Increment = 0
    for i in range(1,len(IndicesOfX)): #All indices apart from the first one
        Increment+=1
        IndicesOfX[i]+=Increment
        #Add 1 to it (because when the first "*" is inserted, the list increases by one)
        #So insert() list method will insert it at an index 1 before desired.
    for i in range(len(IndicesOfX)): #Loop through the amount of "x" indices
        EquationWithX.insert(IndicesOfX[i],"*") #Insert the "*" at the appropiate index
        
        
    """Replace "^" with "**"""
    for i in range(len(EquationWithX)): 
        if EquationWithX[i] == "^": #If the symbol I was using for the superscript ^ is in the equation
            EquationWithX[i] = "**" #Replace it with the python symbol for superscript
    print(EquationWithX)
    MathML = mathml("".join(EquationWithX))
    Math = print_mathml("".join(EquationWithX))
    print(Math)
    
    f = open("OutputFile.html","w")
    f.write("""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Fullest MathML support using MathJax</title>
  <script>window.MathJax = { MathML: { extensions: ["mml3.js", "content-mathml.js"]}};</script>
<script type="text/javascript" async src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.0/MathJax.js?config=MML_HTMLorMML"></script>
</head>
<body><math>"""+MathML+"</math></body></head></html>")
    


            

    

    



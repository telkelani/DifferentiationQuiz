#Unicode Library
"""The purpose of this library is to provide the functionality of adding unicode values to a hash table.
The main purpose of this class is that it would contain a series of functions that will allow me to print unicode values
simply by passing the number into a parameter, so that I don't code for this everytime I want to print a unicode value in my main code
"""
from fractions import Fraction #Importing this library because it has a function where I can convert decimal numbers to fractions
class Unicode:
    """This is going to be class as it will have a few protected methods which will be used only internally in the class
    There will also be public methods like printUnicode and printFraction which will be used in the main program"""

    def __init__(self,_UnicodeDatabase): #Initialize class with only one attribute, the Dictionary of unicode values
        self._UnicodeDatabase = _UnicodeDatabase #Make whatever that was passed when declaring the class as an attribute
        #Anything with self. before it becomes an attribute/method of whatever the object is (self is the default word to describe it)

    def _add_superscripts(self): #This function will be part of the class so has to pass a parameter of self, meaning that this
        #Method belongs to the class object
        for i in range(10): #Loop through 9 numbers, as i starts from 0. 
            if i == 1: #If the counter is equal to 1
                #The alt-code of super script 1,2 and 3 do not follow the pattern of adding onto 8304 so need to be in
                #A separate if statement
                self._UnicodeDatabase["^"+str(i)] = 185 #Add the value of the superscript 1 alt-code by equating the new key to it
                #The key is a circumflex concatenated to it the string form of the number
                #The circumflex represents a superscript in non-unicode,
                #So when an equation is generated this can be passed as a key, which will output th unicode value
            elif 2 <= i <= 3: #Elif not if, as this branches off the first if statement,
                              #Instead of creating a new branch of 2 conditions
                self._UnicodeDatabase["^"+str(i)] = i+176
                #The alt-codes for 2 and 3 superscript are 178 and 179 respectively
            
            else: 
                self._UnicodeDatabase["^"+str(i)] = i+8304
                #The rest of the numbers are added on from the alt-code of 0
        self._UnicodeDatabase["^0.5"] = 8730 #The superscript value for square root (to the power of a 1/2)
        self._UnicodeDatabase["-"] =8315 #I need to add this for negative superscript numbers,
        #I need to add a minus before it, and because it has its own alt-code it had to be added to the dictionary
        #This is outside the for loop as I only need to do this once
        
            
    def _add_common_fractions(self): #Some alt-codes have the unicode characters for common fractions used such as
        #1/2, 1/4, 3/4
        #The three lines below just add the float number of the vulgar fraction as the key
        #To its superscript alt-code value as its value
        self._UnicodeDatabase["0.5"] = 189 
        self._UnicodeDatabase["0.25"] = 188
        self._UnicodeDatabase["0.75"] = 190
    def _add_subscripts(self):
        #Not all of the fractions have unicode values
        #However I can go around the problem by mimicking the look of the fraction
        #The fraction can be displayed by a superscript numerator, a forward slash and a subscript denominator
        for i in range(10):
            self._UnicodeDatabase["_"+str(i)] = i+8320
        #The code above me adds all the unicode subscripts to the dictionary by their keys and respective alt-code values
        #The reason why it is added by 8320 is because the alt-code of subscript 0 is 8320, subscript of 1 = 8321, etc.
        #This means the number of the superscript is just added onto 8320 making a pattern

    def GetUnicodeDictionary(self):
        return self._UnicodeDatabase
        #This function will return the protected variable
        #So that it can be passed as a parameter of non-class functions like chr()
    def _printFraction(self,numerator,denominator): #Pass numerator and denominator of desire fraction
        Dictionary = self.GetUnicodeDictionary()
        str_numerator = str(numerator) #Convert numerators and common
        str_denominator = str(denominator)
        fractionstring = ""
        #The superscripts, the subscripts and the "/" will all be joined
        for i in str_numerator: #For each element in the numerator (i is an element not a counter)
            if i == "-": #If the i is a "-"
                fractionstring+=chr(Dictionary["-"])
                #Add the superscript - to the list
            elif i == "^": #If there is a "^" in the numerator
                #If the fraction is a power and is a 1/2
                if str_numerator == "^1" and str_denominator == "2":
                    fractionstring = chr(Dictionary["^0.5"])
                    #If the string of the numerator is equal to "^1"
                    #Circumflex in front as it would be a power
                    #The denominator would be 2 as
                    #Just return the square root which is exponent to a half 
                else: #If it is not to the power of a 1/2
                    continue #Move on to the next element
                return fractionstring #Return it straight away if it is a 1/2 power
            else: #If it is a number
                fractionstring+=chr(Dictionary["^"+i])
                #Add the superscript of that number by referencing the key of the dictionary 
        fractionstring+="/" #Add the "/" to the fraction
    
        for i in str_denominator:  #For each element in the denominator string
            if "^" in str_numerator:
                fractionstring+=chr(Dictionary["^"+i])
                #The denominators are superscripted instead to make it appear like a power
            else: 
                fractionstring+=chr(Dictionary["_"+i])
                #Add the superscript of each number to the fraction
        return fractionstring #Return the string version of the list
    #This should be able to return a fraction of any size
    #Add common fractions to this
    
    def printUnicode(self,letter):
        Dictionary = self.GetUnicodeDictionary()
        #Get the hash table to be passed into chr()
        if "^" in letter: #If the parameter has a "^"
            NumberAfterCircum = letter[1:]
            #List slice the whole parameter from the second element to ignore the first element
            #All elements after "^"
            """Float Powers"""
            if "." in letter and letter[-1] != "0":
                
                #If it is a float 
                NumberAfterCircum = Fraction(NumberAfterCircum).limit_denominator()
                NumberAfterCircum = "^"+str(NumberAfterCircum)
                #Convert to number after circumflex to fraction
                num = NumberAfterCircum[:NumberAfterCircum.index("/")]
                #Slice out numerator and store in num
                den = NumberAfterCircum[NumberAfterCircum.index("/")+1:]
                #Slice out denominator and store in den
                return self._printFraction(num,den)
                #Pass the numerator and denominator into _printFraction() to output fraction
              
            
            else:
                """Integer Powers"""
                IntPower = "" #Empty string where superscript numbers will come together
                NumberAfterCircum = int(float(NumberAfterCircum))
                #Convert the number after the "^" into an integer given that
                #Integers can also have "." in them such as 15.0
                NumberAfterCircum = str(NumberAfterCircum)
                #Cast it back into a string so that it can be iterated through
                for i in NumberAfterCircum:
                    #For each element in the numbers after the circumflex (i is element of string)
                    if i  == "-": #If the number is negative
                        IntPower+=chr(Dictionary["-"])
                        continue
                        #Add a negative superscript
                    
                    IntPower+=chr(Dictionary["^"+i])
                    #Regardless of whether the power is a negative or not
                    #The superscript of the element will be stored in the IntPower   

                return IntPower #Return the integer power
                 
        else: 
            """Coefficients"""
            letter = Fraction(letter).limit_denominator() #Use Fraction() method from fractions to convert float to fraction
            letter = str(letter) #Change it to a string
            #I needed to copy this code twice because in the first one
            try: #Check to see if the fraction has simplified to an integer number
                int(letter)
                return letter #If it has just return the argument
            except ValueError: #If the fraction doesn't simplify to an integer
                
                num = int("".join(letter[:letter.index("/")]))
                #The numerator is a list of numbers before the index of the "/". Convert the string to an integer 
                den = int("".join(letter[letter.index("/")+1::]))
                #The denominator is a list of numbers after the index "/" to the end of the list. Convert the string to integer
                return self._printFraction(num,den)
                #Pass the numerator and denominator into printFrac() to display it like a fraction


Data = Unicode({})
Data._add_superscripts()
Data._add_common_fractions()
Data._add_subscripts()





